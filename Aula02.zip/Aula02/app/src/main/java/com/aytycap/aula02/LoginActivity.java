package com.aytycap.aula02;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private EditText    mLogin;
    private EditText    mSenha;
    private Button      mLogar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        this.mLogin = (EditText)    findViewById(R.id.login);
        this.mSenha = (EditText)    findViewById(R.id.senha);
        this.mLogar = (Button)      findViewById(R.id.logar);

        this.mLogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginMethod();
            }
        });



    }

    private void loginMethod() {
        String login = this.mLogin.getText().toString();
        String senha = this.mSenha.getText().toString();

        if(login.equals("Leonardo") && senha.equals("123")) {
            this.mLogin.setEnabled(false);
            this.mSenha.setEnabled(false);
            this.mLogar.setEnabled(false);

            Intent intent = new Intent(this, MainActivity.class);

            Bundle bundle = new Bundle();
            bundle.putString("nome", login);
            intent.putExtras(bundle);

            startActivity(intent);
        } else {
            View focus = null;
            if(TextUtils.isEmpty(login)) {
                this.mLogin.setError("Campo vazio");
                focus = this.mLogin;
                focus.requestFocus();
            }

            if(TextUtils.isEmpty(senha)) {
                this.mSenha.setError("Campo vazio");
                focus = this.mSenha;
                focus.requestFocus();
            } else {
                Toast.makeText(getApplicationContext(), "Login ou Senha inválidos", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
